package Controller;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
@Controller
public class UserController {
	@GetMapping("/register")
    public String showForm() {
        return "register"; // This will load register.html
    }

    @PostMapping("/register")
    public String handleRegister(
        @RequestParam String username,
        @RequestParam String password,
        Model model
    ) {
        // Save logic here (e.g., save to DB or service)
        model.addAttribute("message", "User registered successfully!");
        return "result"; // Show success page
    }
}
