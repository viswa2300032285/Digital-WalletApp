package com.kl.SmartWalletApp;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;

@Controller
public class Bankcontroller {
@GetMapping("/home")
public String home() {
return "home";
}

@GetMapping("/login")
public String login() {
	return"login.html";
}

@GetMapping("/signup")
public String signup() {
	return"signup.html";
}
@GetMapping("/sendmoney")
public String sendmoney() {
	return"sendmoney.html";
}
@GetMapping("/recievefunds")
public String recievefunds() {
	return"recievefunds.html";
}
@GetMapping("/wallet")
public String wallet() {
	return"wallet.html";
}
@GetMapping("/digital")
public String digital() {
	return"digital.html";
}
@GetMapping("/spending")
public String spending() {
	return"spending.html";
}
@GetMapping("/helpcenter")
public String helpcenter() {
	return"helpcenter.html";
}
@GetMapping("/livechat")
public String livechat() {
	return"livechat.html";
}
@GetMapping("/contactus")
public String contactus() {
	return"contactus.html";
}
@GetMapping("/virtualcard")
public String virtualcard() {
	return"virtualcard.html";
}
@GetMapping("/RecentActivity")
public String RecentActivity() {
	return"RecentActivity.html";
}
@GetMapping("/dashboard")
	public String dashboard() {
	return "dashboard.html";
}
}