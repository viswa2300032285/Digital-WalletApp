package com.kl.SmartWalletApp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SmartWalletAppApplication {

	public static void main(String[] args) {
		SpringApplication.run(SmartWalletAppApplication.class, args);
		System.out.println("Welcome to Smart Wallet App");
	}

}
