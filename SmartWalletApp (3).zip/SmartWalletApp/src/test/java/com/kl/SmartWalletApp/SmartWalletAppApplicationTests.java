package com.kl.SmartWalletApp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SmartWalletAppApplicationTests {

	@Test
	void contextLoads() {
	}

}
